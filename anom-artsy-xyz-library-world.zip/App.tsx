import { useMemo, useState, useEffect, useRef } from "react";

const COLORS = {
  black: "#000000",
  void: "#0A0A10",
  ground: "#04040a",
  cyan: "#00eaff",
  magenta: "#ff00c8",
  gold: "#d8ae55",
};

type House = {
  id: string;
  title: string;
  breathe: string;
  duration: number;
  subtitle: string;
  tag: string;
  desc: string;
  long: string;
  accent: string;
  world?: string;
};

const MOONBERRY = {
  id: "moonberry",
  title: "MOONBERRY",
  breathe: "4.3s",
  duration: 4.3,
  subtitle: "The arcade moon • Where the games live",
  tag: "MOON WORLD • GAMES WE MADE",
  desc: "Low-gravity arcade. All the builds we shipped orbit here.",
  long: "Moonberry is the playable moon. Low-gravity, high-earn. Every prototype, every farm loop, every patrol sim that actually runs lives here. Not concept art — playable. You ride your Color Corner mount up the beam and land soft. Clifford has a moon post. Tater knocked over the scoreboard once. This is where Anom tests, kids playtest, and Anom Coin is earned for real. EVERYTHING THEY DO EARNS ANOM COIN.",
  games: [
    { name: "Pixel & Dot Farm — Field Test", status: "PLAYABLE", glow: "+12 AC / harvest" },
    { name: "Clifford Patrol: Scent Line", status: "PLAYABLE", glow: "+8 AC / clean sweep" },
    { name: "Tater's Shelf Heist (Executive Edition)", status: "PLAYABLE", glow: "+15 AC / no knock" },
    { name: "Mood Buddies: Hold Space", status: "BETA", glow: "+10 AC / 3-min hold" },
    { name: "Sassy Patrol: Link Check", status: "BETA", glow: "+9 AC / boundary held" },
    { name: "Moonberry Hop — Low-G Mount Race", status: "PLAYABLE", glow: "+20 AC / calm landing" },
  ],
};

const HOUSES: House[] = [
  {
    id: "pixel-dot",
    title: "PIXEL & DOT FARM",
    breathe: "3.2s",
    duration: 3.2,
    subtitle: "Sibling protector story • Cozy build sim",
    tag: "HOUSE ONE",
    desc: "Raise, rescue, and grow. Dot guards, Pixel builds.",
    long: "Cozy farm loop where Dot (the tiny, fierce protector) watches the perimeter while Pixel crafts. No combat, only care. Weather remembers you. Crops keep your handwriting. Sibling logic: if one is scared, the other builds a nightlight.",
  },
  {
    id: "clifford-tater",
    title: "CLIFFORD & TATER SECURITY",
    breathe: "3.6s",
    duration: 3.6,
    subtitle: "K9 Security + Executive Leadership",
    tag: "HOUSE TWO • FACES OF BRAND",
    desc: "8lb Chipin + 20lb tabby. Not mascots — principals.",
    long: "Clifford runs perimeter checks with precision nose-work. Tater runs executive oversight from the highest shelf. Together they model secure attachment, not surveillance. 8lb Chipin, 20lb tabby. Their silhouettes are in every Library window for a reason.",
  },
  {
    id: "mood-buddies",
    title: "MOOD BUDDIES",
    breathe: "3.9s",
    duration: 3.9,
    subtitle: "Vibe-check co-op • Blue / Pink headphones duo",
    tag: "HOUSE THREE",
    desc: "Formerly Mood Memes — now a listening world.",
    long: "Two listeners, one signal. Blue channel holds space, Pink channel reframes. You pick a vibe, they hold it with you. No fixing. Co-op breathwork, color-matching, and headphone handoff. Mood Memes Lounges branch from here — still in build.",
  },
  {
    id: "sassy-patrol",
    title: "SASSY PATROL GUARDIANS",
    breathe: "4.1s",
    duration: 4.1,
    subtitle: "Patrol, not punishment • Boundary with sparkle",
    tag: "HOUSE FOUR",
    desc: "Guardian Links + Moderator Queue backbone.",
    long: "Guardians who patrol with sass and soft power. They don't bounce — they guide. Each Guardian holds a Link, each Link holds a boundary. Moderator Queue feeds them, Sentinel Code shapes them. SFW. Identity Guard. Mood-first respect.",
  },
];

const COLOR_BEINGS = [
  {
    title: "FREE PIC",
    label: "ENTRY MOUNT",
    copy: "Pick from the living archive. Every line is a trail. Ride to Library, to Farm, to Patrol HQ. Everything you do earns Anom Coin.",
    emote: "◐",
    accent: COLORS.cyan,
  },
  {
    title: "HIGH-END PIC",
    label: "RARE MOUNT",
    copy: "Ink with history. Thicker coat, slower breathe. Earns 2x Anom Coin when you ride calm — EVERYTHING THEY DO EARNS ANOM COIN.",
    emote: "⬙",
    accent: COLORS.magenta,
  },
  {
    title: "COLOR YOURSELF",
    label: "BOND MOUNT",
    copy: "You color it. We remember the stroke. It becomes yours. Earns Anom Coin — everything you do earns Anom Coin. Color, harvest, patrol — all earns.",
    emote: "✦",
    accent: COLORS.gold,
  },
];

const REMAINING = [
  "Mood Memes Lounges",
  "Public Profiles",
  "Identity Shop profiles",
  "Feed Posts soft-delete",
  "Reports + Blocks",
  "Guardian Links",
  "Moderator Queue",
];

const FARM_ZONES = [
  { id: "hub", name: "Moonberry Farm", role: "HUB", desc: "Pastoral luminous home. Farmhouse warm windows, berry fields, well, paths.", accent: "#d8ae55" },
  { id: "saloon", name: "Sassy Saloon HQ", role: "MOUNT EQUIP", desc: "Equip ridables. 2x speed when mounted. Rainbow Pop / Paint Random Pop skins.", accent: "#00eaff" },
  { id: "rainbow", name: "Rainbow Fields", role: "ZONE • JOY", desc: "Low grass, prism berries, co-op harvest. Dot guards the row.", accent: "#ff00c8" },
  { id: "peaks", name: "Cosmic Peaks", role: "ZONE • WONDER", desc: "Mountains under moon, thin air glide. Cosmic Dragon loves this.", accent: "#00eaff" },
  { id: "lab", name: "Tech Lab", role: "ZONE • LOGIC", desc: "Build logic, test mounts, Sentinel checks. No toxicity, mood-first.", accent: "#d8ae55" },
];

const FARM_MOUNTS = [
  { name: "Rainbow Unicorn", trait: "Speed", detail: "Flagship sprinter. Rainbow Pop skin.", color: "#00eaff" },
  { name: "Cosmic Dragon", trait: "Flight", detail: "Glide over Peaks. Outer orbit 84px 6s.", color: "#ff00c8" },
  { name: "Armored Light Pegasus", trait: "Scout", detail: "Light recon, fast turn.", color: "#d8ae55" },
  { name: "Armored Dark Pegasus", trait: "Tank", detail: "Heavy, calm, kids ride steady.", color: "#8a6d3b" },
  { name: "White Unicorn", trait: "Healer", detail: "Healer. Inner orbit 46px 3.8s.", color: "#ffffff" },
  { name: "Nova Unicorn", trait: "Variant • Speed+", detail: "Pro build variant — reconciled.", color: "#00eaff" },
  { name: "Armored Night Pegasus", trait: "Variant • Tank+", detail: "Pro build variant — reconciled.", color: "#141423" },
];

const FARM_VIRTUES = [
  { name: "Empathy • Upstander", line: "Tater protects Clifford. Stand up for your pack.", color: "#00eaff" },
  { name: "Joy • Sharing", line: "Anom Coin shines brighter when shared.", color: "#ff00c8" },
  { name: "Gratitude • Nature Love", line: "Moonberries grow when you thank earth.", color: "#d8ae55" },
  { name: "Wonder • Curiosity", line: "Ask what the berry remembers.", color: "#00eaff" },
  { name: "Logic • Digital Kindness", line: "Kind code, kind play.", color: "#ffffff" },
];

const FARM_GAMES = [
  { k: "01", title: "Sky Navigator", tag: "FLAGSHIP • WASD EXPLORER", desc: "Anom's Universe Pro Edition (Black Brand). WASD explorer, coin collection, mountable rides 2x at Sassy Saloon, skin switching Rainbow Pop / Paint Random Pop. This is the playable core we built.", accent: "#00eaff" },
  { k: "02", title: "Off-Grid", tag: "WORLD TYPE • MEMBERS BUILD", desc: "Members build their own grids off the farm hub. Cozy farm logic, weather remembers you. Pixel & Dot relation legible.", accent: "#d8ae55" },
  { k: "03", title: "Paint Your Ridables", tag: "COLOR LOOP", desc: "Physical coloring → upload → earn Anom Coin → ride what you colored. Kids color travel animals in Anom's Corner — those animals carry you to Moonberry. Everything earns.", accent: "#ff00c8" },
  { k: "04", title: "Virtue Quests", tag: "QUESTS • VOICE LINES", desc: "Collect Empathy, Joy, Gratitude, Wonder, Logic. Each berry has a voice line. Patrol, not bouncers. Sentinel Code active on planet too.", accent: "#ffffff" },
];

export default function App() {
  const [selected, setSelected] = useState<House | null>(null);
  const [portalEngaged, setPortalEngaged] = useState(false);
  const [entered, setEntered] = useState(false);
  const [activeNav, setActiveNav] = useState<string>("top");
  const heroRef = useRef<HTMLDivElement>(null);

  const stars = useMemo(() => {
    return Array.from({ length: 180 }).map((_, i) => {
      const c = [COLORS.cyan, COLORS.magenta, COLORS.gold][i % 3];
      return {
        id: i,
        left: Math.random() * 100,
        top: Math.random() * 100,
        size: Math.random() * 1.8 + 0.6,
        color: c,
        delay: Math.random() * 6,
        dur: 4 + Math.random() * 4,
        drift: 20 + Math.random() * 80,
      };
    });
  }, []);

  useEffect(() => {
    if (portalEngaged) {
      const t = setTimeout(() => setEntered(true), 850);
      return () => clearTimeout(t);
    }
  }, [portalEngaged]);

  const scrollTo = (id: string) => {
    setActiveNav(id);
    document.getElementById(id)?.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <div className="min-h-screen w-full bg-black text-white selection:bg-[#ff00c8]/30 selection:text-white overflow-x-hidden">
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Space+Mono:wght@400;700&family=Inter:wght@300;400;500;600&display=swap');
        *{ font-family: Inter, system-ui, -apple-system, sans-serif; }
        .mono{ font-family: "Space Mono", monospace; }
        .label{ font-family: "Space Mono", monospace; letter-spacing: 0.22em; font-size: 10px; text-transform: uppercase; }
        .label-wide{ font-family: "Space Mono", monospace; letter-spacing: 0.32em; font-size: 10px; text-transform: uppercase; }
        @keyframes breathe {
          0%,100%{ transform: scale(1); }
          50%{ transform: scale(1.028); }
        }
        @keyframes breathe-glow {
          0%,100%{ transform: scale(1); filter: brightness(1); }
          50%{ transform: scale(1.035); filter: brightness(1.12); }
        }
        @keyframes floatY {
          0%,100%{ transform: translateY(0px); }
          50%{ transform: translateY(-14px); }
        }
        @keyframes drift {
          0%{ transform: translate(0,0); opacity: 0.2; }
          50%{ opacity: 0.9; }
          100%{ transform: translate(var(--dx), var(--dy)); opacity: 0.15; }
        }
        @keyframes moonOrbit {
          from{ transform: rotate(0deg) translateX(140px) rotate(0deg); }
          to{ transform: rotate(360deg) translateX(140px) rotate(-360deg); }
        }
        @keyframes moonOrbit54 {
          from{ transform: rotate(0deg) translateX(54px) rotate(0deg); }
          to{ transform: rotate(360deg) translateX(54px) rotate(-360deg); }
        }
        @keyframes mountOrbit84 {
          from{ transform: rotate(0deg) translateX(84px) rotate(0deg); }
          to{ transform: rotate(360deg) translateX(84px) rotate(-360deg); }
        }
        @keyframes mountOrbit46 {
          from{ transform: rotate(0deg) translateX(46px) rotate(0deg); }
          to{ transform: rotate(360deg) translateX(46px) rotate(-360deg); }
        }
        @keyframes farmBreathe {
          0%,100%{ transform: scale(1); }
          50%{ transform: scale(1.05); }
        }
        @keyframes blurResolve {
          0%{ filter: blur(18px) brightness(0.7); opacity: 0.6; transform: scale(1.03); }
          60%{ filter: blur(4px) brightness(1.05); opacity: 1; }
          100%{ filter: blur(0px) brightness(1); opacity: 1; transform: scale(1); }
        }
        @keyframes threadPulse {
          0%,100%{ stroke-opacity: 0.5; }
          50%{ stroke-opacity: 1; }
        }
        @keyframes gridShift {
          from{ background-position: 0 0, 0 0; }
          to{ background-position: 0 80px, 0 80px; }
        }
        @media (prefers-reduced-motion: reduce){
          *, *::before, *::after{
            animation: none !important;
            transition: none !important;
          }
        }
        .glass{
          background: linear-gradient(135deg, rgba(255,255,255,0.12), rgba(255,255,255,0.04));
          backdrop-filter: blur(18px);
          -webkit-backdrop-filter: blur(18px);
          border: 1px solid rgba(255,255,255,0.18);
        }
        .glass-gold{
          background: linear-gradient(135deg, rgba(216,174,85,0.12), rgba(255,255,255,0.03));
          backdrop-filter: blur(18px);
          border: 1px solid rgba(216,174,85,0.35);
        }
        .portal-ring{
          box-shadow: 0 0 18px ${COLORS.cyan}, 0 0 36px ${COLORS.magenta}, 0 0 54px ${COLORS.gold}, inset 0 0 20px rgba(255,255,255,0.08);
        }
        .portal-core{
          box-shadow: inset 0 0 60px rgba(216,174,85,0.25), inset 0 0 120px rgba(0,0,0,0.8);
        }
        .grid-persp{
          background-image: 
            linear-gradient(rgba(0,234,255,0.28) 1px, transparent 1px),
            linear-gradient(90deg, rgba(0,234,255,0.18) 1px, transparent 1px);
          background-size: 80px 80px, 80px 80px;
          mask-image: linear-gradient(to top, black 20%, transparent 95%);
          -webkit-mask-image: linear-gradient(to top, black 20%, transparent 95%);
        }
      `}</style>

      {/* Stars */}
      <div className="pointer-events-none fixed inset-0 z-0 overflow-hidden bg-black">
        {stars.map((s) => (
          <div
            key={s.id}
            className="absolute rounded-full"
            style={{
              left: `${s.left}%`,
              top: `${s.top}%`,
              width: s.size,
              height: s.size,
              background: s.color,
              boxShadow: `0 0 ${s.size * 6}px ${s.color}`,
              opacity: 0.7,
              animation: `drift ${s.dur}s ease-in-out ${s.delay}s infinite alternate, floatY 6s ease-in-out ${s.delay}s infinite`,
              // @ts-ignore
              "--dx": `${(Math.random() - 0.5) * s.drift}px`,
              "--dy": `${(Math.random() - 0.5) * s.drift}px`,
            } as any}
          />
        ))}
      </div>

      {/* Top nav */}
      <nav className="relative z-20 flex items-center justify-between px-6 md:px-10 py-5">
        <div className="flex items-center gap-3">
          <div
            className="h-9 w-9 rounded-full grid place-items-center mono text-[10px] font-bold tracking-[0.2em] portal-ring"
            style={{
              background: COLORS.void,
              animation: "breathe-glow 2.6s ease-in-out infinite",
              color: COLORS.cyan,
            }}
          >
            AO
          </div>
          <div className="flex flex-col">
            <span className="label text-white/70">ANOMARTSY.XYZ</span>
            <span className="label-wide text-white/30 -mt-0.5">HOMEWORLD / LIBRARY</span>
          </div>
        </div>
        <div className="hidden md:flex items-center gap-6">
          <button onClick={() => scrollTo("moonberry-farm")} className={`label transition px-2 py-1 rounded ${activeNav==="moonberry-farm" ? "text-[#00eaff] bg-[#00eaff]/10 border border-[#00eaff]/20" : "text-white/60 hover:text-white"}`}>FARM{activeNav==="moonberry-farm" && " •"}</button>
          <button onClick={() => scrollTo("color")} className={`label transition px-2 py-1 rounded ${activeNav==="color" ? "text-[#00eaff] bg-white/10" : "text-white/60 hover:text-white"}`}>COLOR{activeNav==="color" && " •"}</button>
          <button onClick={() => scrollTo("houses")} className={`label transition px-2 py-1 rounded ${activeNav==="houses" ? "text-[#00eaff] bg-white/10" : "text-white/60 hover:text-white"}`}>HOUSES{activeNav==="houses" && " •"}</button>
          <button onClick={() => scrollTo("moonberry")} className={`label transition px-2 py-1 rounded ${activeNav==="moonberry" ? "text-[#d8ae55] bg-[#d8ae55]/15" : "text-[#d8ae55]/80 hover:text-[#d8ae55]"}`}>MOONBERRY{activeNav==="moonberry" && " •"}</button>
          <button onClick={() => scrollTo("build")} className={`label transition px-2 py-1 rounded ${activeNav==="build" ? "text-[#ff00c8] bg-[#ff00c8]/10" : "text-white/60 hover:text-white"}`}>IN BUILD{activeNav==="build" && " •"}</button>
          <a href="https://anomarsty.lol" target="_blank" rel="noopener" className="label px-4 py-2 rounded-full glass-gold text-[#d8ae55] hover:bg-[#d8ae55]/10 transition">ANOMARSTY.LOL →</a>
        </div>
        <a href="https://anomarsty.lol" target="_blank" rel="noopener" className="md:hidden label px-3 py-2 rounded-full glass-gold text-[#d8ae55]">STORE</a>
      </nav>

      {/* HERO */}
      <section ref={heroRef} id="top" className="relative z-10 w-full min-h-[92vh] flex flex-col items-center justify-center px-4 pt-6 pb-20 overflow-hidden max-w-[100vw]">
        {/* Cyan grid perspective */}
        <div className="pointer-events-none absolute bottom-0 left-0 right-0 w-full h-[56%] origin-bottom overflow-hidden" style={{ perspective: "700px" }}>
          <div
            className="absolute inset-0 grid-persp"
            style={{
              transform: "rotateX(68deg) translateZ(0)",
              transformOrigin: "bottom center",
              animation: "gridShift 8s linear infinite",
            }}
          />
          {/* magenta horizon */}
          <div className="absolute top-0 left-0 right-0 h-[1px] bg-[#ff00c8] shadow-[0_0_18px_#ff00c8,0_0_36px_#ff00c8]" />
          <div className="absolute top-0 left-0 right-0 h-[18px] bg-gradient-to-b from-[#ff00c8]/20 to-transparent blur-[2px]" />
        </div>

        {/* Moon orbit */}
        <div className="pointer-events-none absolute left-1/2 top-[38%] -translate-x-1/2 -translate-y-1/2 w-[520px] h-[520px] md:w-[720px] md:h-[720px]">
          <div
            className="absolute left-1/2 top-1/2 h-1 w-1"
            style={{ animation: "moonOrbit 4s linear infinite" }}
          >
            <div className="h-2.5 w-2.5 -translate-x-1/2 -translate-y-1/2 rounded-full bg-[#d8ae55] shadow-[0_0_12px_#d8ae55]" />
          </div>
        </div>

        {/* Portal */}
        <div className="relative mt-8 md:mt-2">
          {/* glow aura behind */}
          <div className="absolute inset-0 -z-10 blur-[42px] opacity-60 rounded-full" style={{ background: `radial-gradient(circle, ${COLORS.cyan}22, ${COLORS.magenta}18, transparent 70%)` }} />
          <button
            aria-label="Enter Library World"
            onClick={() => setPortalEngaged(true)}
            className={`group relative rounded-full p-[2px] transition-all duration-700 ${portalEngaged ? "scale-[3.2] opacity-0 pointer-events-none" : "scale-100 opacity-100 hover:scale-[1.02]"}`}
            style={{ animation: "breathe 4.4s ease-in-out infinite" }}
          >
            <div className="portal-ring rounded-full p-[10px] md:p-[14px] bg-[#04040a]/80">
              <div className="portal-core relative h-[300px] w-[300px] md:h-[520px] md:w-[520px] rounded-full overflow-hidden bg-[#0a0a10]">
                {/* Library interior illustration */}
                <div className="absolute inset-0">
                  {/* warm interior gradient */}
                  <div className="absolute inset-0 bg-[radial-gradient(120%_90%_at_50%_20%,#2a1f14_0%,#1a150f_28%,#0e0b08_62%,#04040a_92%)]" />
                  {/* lamp glows */}
                  <div className="absolute left-[18%] top-[18%] h-[120px] w-[120px] rounded-full bg-[#d8ae55]/25 blur-[18px]" />
                  <div className="absolute right-[22%] top-[22%] h-[100px] w-[100px] rounded-full bg-[#ffcf7a]/20 blur-[16px]" />
                  {/* bookshelves */}
                  <div className="absolute inset-x-0 bottom-[38%] top-[8%] flex justify-center gap-[3%] px-[10%] opacity-90">
                    {[0,1,2].map((s) => (
                      <div key={s} className="flex-1 flex flex-col gap-1">
                        {Array.from({ length: 9 }).map((_, i) => (
                          <div key={i} className="h-[9%] w-full flex gap-[2px]">
                            {Array.from({ length: 8 + (i%3) }).map((__, j) => (
                              <div
                                key={j}
                                className="flex-1 rounded-[1px]"
                                style={{
                                  background: `hsl(${32 + j*3} 28% ${18 + (j%4)*4}%)`,
                                  opacity: 0.85,
                                }}
                              />
                            ))}
                          </div>
                        ))}
                      </div>
                    ))}
                  </div>
                  {/* floor + lamps posts */}
                  <div className="absolute bottom-0 inset-x-0 h-[42%] bg-gradient-to-t from-[#0b0805] via-[#161009]/80 to-transparent" />
                  <div className="absolute bottom-[18%] left-[30%] h-[44%] w-[2px] bg-gradient-to-t from-[#d8ae55]/60 to-transparent" />
                  <div className="absolute bottom-[18%] right-[30%] h-[44%] w-[2px] bg-gradient-to-t from-[#d8ae55]/60 to-transparent" />
                  <div className="absolute bottom-[54%] left-[29%] h-3 w-6 -translate-x-1/2 rounded-full bg-[#ffecad] shadow-[0_0_18px_#d8ae55]" />
                  <div className="absolute bottom-[54%] right-[29%] h-3 w-6 translate-x-1/2 rounded-full bg-[#ffecad] shadow-[0_0_18px_#d8ae55]" />
                  {/* Tater & Clifford silhouettes */}
                  <div className="absolute bottom-[12%] left-1/2 -translate-x-1/2 flex items-end gap-4">
                    {/* Tater 20lb tabby */}
                    <div className="relative">
                      <div className="h-[34px] w-[56px] rounded-t-[18px] bg-black/80 blur-[0.2px]" />
                      <div className="absolute -top-2 left-2 h-3 w-3 rotate-45 bg-black/80" />
                      <div className="absolute -top-2 right-2 h-3 w-3 rotate-45 bg-black/80" />
                      <div className="absolute -bottom-1 left-1 right-1 h-[6px] rounded-full bg-black/60 blur-[1px]" />
                    </div>
                    {/* Clifford 8lb Chipin */}
                    <div className="relative -mb-1">
                      <div className="h-[26px] w-[32px] rounded-t-[12px] bg-black/90" />
                      <div className="absolute -top-1.5 left-1/2 -translate-x-1/2 h-4 w-4 rounded-full bg-black/90" />
                      <div className="absolute -top-1 left-0 h-2.5 w-1.5 rotate-12 rounded-full bg-black/90" />
                      <div className="absolute -top-1 right-0 h-2.5 w-1.5 -rotate-12 rounded-full bg-black/90" />
                    </div>
                  </div>
                  {/* subtle vignette readability layer */}
                  <div className="absolute inset-0 bg-[radial-gradient(80%_80%_at_50%_50%,transparent_58%,rgba(0,0,0,0.55)_100%)]" />
                </div>

                {/* enter hint */}
                <div className="absolute bottom-6 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2">
                  <div className="h-6 w-6 rounded-full border border-white/30 grid place-items-center bg-black/30 backdrop-blur">
                    <span className="text-[10px]">↗</span>
                  </div>
                  <span className="label text-white/70 whitespace-nowrap">CLICK TO ENTER</span>
                </div>
              </div>
            </div>
          </button>
        </div>

        {/* Headline */}
        <div className="relative mt-10 md:mt-12 text-center max-w-[920px] px-2">
          <h1 className="mono text-[32px] md:text-[64px] leading-[0.9] font-bold tracking-[-0.02em] text-white">
            ENTER LIBRARY <span className="text-[#00eaff]">WORLD</span>
          </h1>
          <p className="mt-4 mono text-[11px] md:text-[12px] tracking-[0.22em] md:tracking-[0.28em] text-white/60 uppercase">
            Anom&apos;s Corner · Color Corner · Tater &amp; Clifford · Pixel &amp; Dot · Moonberry
          </p>
          <div className="mt-6 flex flex-wrap justify-center gap-2">
            <span className="label px-3 py-1 rounded-full glass text-white/70">BLACK MODERN · #000000</span>
            <span className="label px-3 py-1 rounded-full glass text-white/50">VOID #0A0A10</span>
            <span className="label px-3 py-1 rounded-full glass-gold text-[#d8ae55]">ARCHIVE CANON</span>
          </div>
        </div>

        {/* Portal entry overlay after click */}
        {portalEngaged && (
          <div className="fixed inset-0 z-[60] bg-black flex items-center justify-center">
            <div className="absolute inset-0 bg-[radial-gradient(90%_70%_at_50%_50%,#1e160c,#04040a_70%)]" />
            <div className="relative text-center px-6 max-w-[520px]">
              <div className="mono text-[11px] tracking-[0.4em] text-[#d8ae55] mb-6">LIBRARY WORLD · SYNCING</div>
              <div className="h-[1px] w-full bg-gradient-to-r from-transparent via-[#00eaff] to-transparent mb-8 opacity-60" />
              <h2 className="mono text-3xl md:text-4xl font-bold leading-tight">The lamps are on.<br/>Tater saved your seat.</h2>
              <div className="mt-4 space-y-3">
                <p className="text-[14px] leading-relaxed text-white/60">You are entering through the homeworld portal.</p>
                <div className="inline-flex px-3 py-1 rounded-full bg-[#d8ae55]/15 border border-[#d8ae55]/30">
                  <span className="label text-[#d8ae55] font-bold">EVERYTHING THEY DO EARNS ANOM COIN</span>
                </div>
                <p className="text-[12px] leading-relaxed text-white/40">10 AC = $1 USD utility token — building, terrain, sky, structures, decorations, textures, Mood Patches. Build currency.</p>
              </div>
              <button
                onClick={() => { setPortalEngaged(false); setEntered(false); scrollTo("moonberry-farm"); }}
                className="mt-8 mono text-xs tracking-[0.22em] px-6 py-3 rounded-full bg-white text-black hover:bg-[#00eaff] transition"
              >
                CONTINUE TO MOONBERRY FARM
              </button>
              {entered && (
                <div className="mt-6 label text-[#00eaff] animate-pulse">breathing at 3.2s / 3.6s / 3.9s / 4.1s — houses alive</div>
              )}
            </div>
          </div>
        )}
      </section>

      {/* MOONBERRY FARM — KIDS PLANET - FEATURED WORLD INSIDE AO */}
      <section id="moonberry-farm" className="relative z-10 w-full overflow-hidden border-y border-[#00eaff]/20">
        {/* full-bleed pastoral luminous world */}
        <div className="absolute inset-0 bg-[#000000]">
          {/* base shell near-black */}
          <div className="absolute inset-0 bg-[radial-gradient(110%_85%_at_50%_8%,#1a2233_0%,#12182a_12%,#0a0a14_28%,#000000_62%)]" />
          {/* soft aurora over mountains */}
          <div className="absolute inset-0 bg-[radial-gradient(80%_60%_at_70%_10%,rgba(0,234,255,0.12),transparent_60%),radial-gradient(70%_50%_at_20%_15%,rgba(255,0,200,0.10),transparent_60%),radial-gradient(60%_40%_at_50%_90%,rgba(216,174,85,0.10),transparent_70%)]" />
          {/* stars - denser here */}
          <div className="absolute inset-0 opacity-70" style={{ backgroundImage: `radial-gradient(rgba(0,234,255,0.5) 1px, transparent 1px), radial-gradient(rgba(216,174,85,0.4) 1px, transparent 1px), radial-gradient(rgba(255,0,200,0.35) 1px, transparent 1px)`, backgroundSize: "88px 88px, 120px 120px, 160px 160px", backgroundPosition: "0 0, 40px 30px, 10px 80px" }} />
          {/* mountains silhouette */}
          <div className="absolute bottom-[38%] inset-x-0 h-[28%] opacity-90">
            <svg viewBox="0 0 1440 220" preserveAspectRatio="none" className="w-full h-full">
              <path d="M0 180 L120 60 L260 140 L380 30 L520 110 L640 50 L780 130 L920 20 L1060 110 L1180 60 L1320 150 L1440 100 L1440 220 L0 220 Z" fill="#0a0f1a" />
              <path d="M0 200 L180 90 L320 160 L480 60 L600 130 L740 70 L880 150 L1040 50 L1160 130 L1280 80 L1440 140 L1440 220 L0 220 Z" fill="#10182a" opacity="0.8" />
            </svg>
            {/* moon behind peaks - 54px orbit reference */}
            <div className="absolute left-[72%] top-[12%]">
              <div className="relative w-[92px] h-[92px]">
                <div className="absolute left-1/2 top-1/2 h-1 w-1" style={{ animation: "moonOrbit54 4s linear infinite" }}>
                  <div className="h-[14px] w-[14px] -translate-x-1/2 -translate-y-1/2 rounded-full bg-[#e8e6d9] shadow-[0_0_18px_rgba(232,230,217,0.9),0_0_36px_rgba(216,174,85,0.5)]" />
                </div>
                <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 h-[22px] w-[22px] rounded-full bg-[#0a0a10] border border-white/10 opacity-30" />
              </div>
            </div>
          </div>
          {/* farm ground with paths */}
          <div className="absolute bottom-0 inset-x-0 h-[42%] bg-gradient-to-t from-[#0d0b08] via-[#14120f] to-transparent">
            {/* glowing berry fields - luminous pastel */}
            <div className="absolute inset-x-[4%] top-[18%] bottom-[14%] opacity-90">
              <div className="absolute inset-0 grid grid-cols-12 gap-[3%]">
                {Array.from({ length: 48 }).map((_, i) => {
                  const colors = ["#00eaff", "#d8ae55", "#ff9bd6", "#7affb3", "#ffd166"];
                  const c = colors[i % 5];
                  return <div key={i} className="h-1 w-1 md:h-1.5 md:w-1.5 rounded-full" style={{ background: c, boxShadow: `0 0 8px ${c}`, opacity: 0.7 + Math.random()*0.3 }} />;
                })}
              </div>
              {/* paths - woven, never right angle */}
              <svg viewBox="0 0 800 200" className="absolute inset-0 w-full h-full opacity-40" fill="none">
                <path d="M-20 140 C 120 90, 220 160, 360 110 S 560 40, 820 100" stroke="#d8ae55" strokeWidth="1.2" strokeDasharray="6 8" opacity="0.5" />
                <path d="M-20 170 C 140 120, 300 190, 460 130 S 620 70, 820 130" stroke="rgba(255,255,255,0.25)" strokeWidth="0.8" strokeDasharray="4 10" />
              </svg>
            </div>
            {/* farmhouse - warm windows */}
            <div className="absolute left-[10%] md:left-[14%] bottom-[28%] w-[120px] md:w-[168px]">
              <div className="relative">
                <div className="h-[52px] md:h-[72px] w-full bg-[#1a150e] border border-[#d8ae55]/20 rounded-t-[8px] relative overflow-hidden">
                  <div className="absolute top-[14%] left-[14%] h-[18px] w-[18px] md:h-[22px] md:w-[22px] bg-[#ffec9a] shadow-[0_0_14px_#ffec9a,0_0_28px_#d8ae55] rounded-[2px]" />
                  <div className="absolute top-[14%] right-[22%] h-[18px] w-[18px] md:h-[22px] md:w-[22px] bg-[#ffec9a] shadow-[0_0_14px_#ffec9a,0_0_28px_#d8ae55] rounded-[2px]" />
                  <div className="absolute bottom-[18%] left-1/2 -translate-x-1/2 h-[22px] w-[14px] bg-[#2a1f12] border border-[#d8ae55]/30" />
                </div>
                <div className="absolute -top-[18px] left-1/2 -translate-x-1/2 w-[108%] h-[20px] bg-[#0f0d0a] rotate-1 border border-[#d8ae55]/10 rounded-t-[12px]" style={{ clipPath: "polygon(5% 100%, 50% 0%, 95% 100%)" }} />
                <div className="absolute -bottom-1 left-1/2 -translate-x-1/2 w-[70%] h-[6px] bg-black/60 blur-[2px] rounded-full" />
                {/* breathing 5% */}
                <div className="absolute inset-0 pointer-events-none" style={{ animation: "farmBreathe 5.4s ease-in-out infinite" }} />
              </div>
              <div className="mt-2 label text-[#d8ae55]/70 text-[8px] text-center">FARMHOUSE • WARM WINDOWS • BREATHING 5%</div>
            </div>
            {/* well */}
            <div className="absolute left-[42%] md:left-[44%] bottom-[22%]">
              <div className="h-[28px] w-[32px] rounded-full border border-white/20 bg-[#0a0a10] relative">
                <div className="absolute inset-[4px] rounded-full bg-[#04040a] border border-[#00eaff]/20" />
                <div className="absolute -top-3 left-1/2 -translate-x-1/2 w-[28px] h-[10px] bg-[#141423] border border-white/10 rotate-1" />
              </div>
              <div className="mt-1 label text-white/20 text-[7px] text-center">WELL</div>
            </div>
            {/* mount orbits demo */}
            <div className="absolute right-[12%] md:right-[18%] bottom-[34%]">
              <div className="relative w-[96px] h-[96px] md:w-[120px] md:h-[120px]">
                {/* outer 84px 6s */}
                <div className="absolute left-1/2 top-1/2 h-1 w-1" style={{ animation: "mountOrbit84 6s linear infinite" }}>
                  <div className="h-2 w-2 -translate-x-1/2 -translate-y-1/2 rounded-full bg-[#ff00c8] shadow-[0_0_10px_#ff00c8]" title="Cosmic Dragon outer orbit 84px 6s" />
                </div>
                {/* inner 46px 3.8s */}
                <div className="absolute left-1/2 top-1/2 h-1 w-1" style={{ animation: "mountOrbit46 3.8s linear infinite" }}>
                  <div className="h-2 w-2 -translate-x-1/2 -translate-y-1/2 rounded-full bg-[#00eaff] shadow-[0_0_10px_#00eaff]" title="White Unicorn inner orbit 46px 3.8s" />
                </div>
                <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 h-1 w-1 rounded-full bg-white/40" />
              </div>
              <div className="label text-white/30 text-[7px] text-center mt-1">ORBITS NEVER SYNCED<br/>54px 4s / 84px 6s / 46px 3.8s</div>
            </div>
          </div>
          {/* readability layer over bright world so AO dark nav stays readable */}
          <div className="absolute inset-0 bg-[linear-gradient(180deg,rgba(0,0,0,0.88)_0%,rgba(0,0,0,0.55)_18%,rgba(0,0,0,0.28)_42%,rgba(0,0,0,0.65)_78%,rgba(0,0,0,0.92)_100%)]" />
          <div className="absolute inset-0 bg-[radial-gradient(90%_70%_at_50%_20%,transparent_40%,rgba(0,0,0,0.7)_100%)]" />
        </div>

        {/* curved woven thread connection from Library World to Moonberry Farm */}
        <div className="pointer-events-none absolute top-0 left-1/2 -translate-x-1/2 w-full max-w-[1280px] h-[120px] z-20 hidden md:block">
          <svg viewBox="0 0 1280 120" className="w-full h-full" fill="none">
            <path d="M640 0 C 580 28, 520 48, 420 62 S 260 88, 180 110" stroke="#d8ae55" strokeWidth="1.4" opacity="0.9" style={{ animation: "threadPulse 3.2s ease-in-out infinite" }} />
            <path d="M640 0 C 700 26, 760 46, 860 60 S 1040 86, 1120 108" stroke="#00eaff" strokeWidth="1.2" opacity="0.8" style={{ animation: "threadPulse 4.1s ease-in-out infinite" }} />
            <path d="M640 0 C 640 40, 640 60, 640 90" stroke="white" strokeWidth="0.6" strokeDasharray="4 6" opacity="0.35" />
            <g>
              <circle cx="640" cy="6" r="3.5" fill="#d8ae55" opacity="0.9" />
              <circle cx="180" cy="110" r="2.5" fill="#d8ae55" />
              <circle cx="1120" cy="108" r="2.5" fill="#00eaff" />
            </g>
          </svg>
          <div className="absolute left-1/2 top-[6px] -translate-x-1/2 label text-[#d8ae55] text-[8px] tracking-[0.32em] bg-black/60 px-2 py-0.5 rounded-full border border-[#d8ae55]/20">WOVEN THREAD • LIBRARY → FARM • CURVED NEVER RIGHT ANGLE</div>
        </div>

        <div className="relative z-10 w-full px-6 md:px-10 py-14 md:py-[88px]">
          <div className="mx-auto max-w-[1280px]">
            {/* Header */}
            <div className="flex flex-col gap-5">
              <div className="flex flex-wrap items-center gap-3">
                <span className="label px-3 py-1 rounded-full bg-[#00eaff]/15 text-[#00eaff] border border-[#00eaff]/30 shadow-[0_0_12px_rgba(0,234,255,0.25)]">● ACTIVE • LIVE • PLAYABLE CORE</span>
                <span className="label px-3 py-1 rounded-full bg-[#d8ae55]/20 text-[#d8ae55] border border-[#d8ae55]/40 font-bold">EVERYTHING THEY DO EARNS ANOM COIN</span>
                <span className="label px-2.5 py-1 rounded-full glass text-white/40">ANOM'S CORNER &gt; MOONBERRY FARM • 10 AC = $1 BUILD CURRENCY</span>
              </div>
              <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-6">
                <div className="max-w-[760px]">
                  <h2 className="mono font-bold text-white leading-[0.9] tracking-[0.2em] text-[26px] md:text-[40px] lg:text-[46px]" style={{ letterSpacing: "0.2em" }}>MOONBERRY FARM — KIDS PLANET</h2>
                  <p className="mt-4 text-[13px] md:text-[14px] leading-[1.7] text-white/65 max-w-[680px]">
                    A kids planet <span className="text-white">within</span> Anom's Universe, not a separate app. Pastoral and luminous against near-black shell: cozy farmhouse warm windows, glowing berry fields, well, paths, mountains, moon. This is where the games we made live. Every action earns Anom Coin — color, harvest, patrol, hold space, link check. 10 AC = $1 utility for building, terrain, sky, structures, decorations, textures, Mood Patches.
                  </p>
                  <div className="mt-4 flex flex-wrap gap-2">
                    <span className="label px-2.5 py-1 rounded-full bg-white/[0.06] border border-white/10 text-white/50">PRO EDITION • BLACK BRAND</span>
                    <span className="label px-2.5 py-1 rounded-full bg-[#00eaff]/10 border border-[#00eaff]/20 text-[#00eaff]">WASD • COINS • 2X MOUNT AT SALOON</span>
                    <span className="label px-2.5 py-1 rounded-full glass-gold text-[#d8ae55] font-bold">ANOM COIN • 10 AC = $1 • BUILDING CURRENCY</span>
                    <span className="label px-2.5 py-1 rounded-full bg-[#d8ae55]/20 border border-[#d8ae55]/30 text-[#d8ae55] font-bold">EVERYTHING EARNS AC</span>
                  </div>
                </div>
                <div className="lg:w-[320px] shrink-0">
                  <div className="glass rounded-[18px] p-4 border border-[#00eaff]/20">
                    <div className="label text-[#d8ae55] mb-2 font-bold">ECONOMY • CANON UPDATE</div>
                    <div className="mono text-[11px] leading-[1.6] text-white/70">
                      Anom's Corner<br/>
                      <span className="text-white/30">↳</span> Color Corner — you color travel animal <span className="text-[#d8ae55]">+AC</span><br/>
                      <span className="text-white/30">↳</span> <span className="text-[#d8ae55] font-bold">Moonberry Farm</span> — you ride what you colored <span className="text-[#d8ae55]">+AC</span><br/>
                      <span className="text-white/30">↳</span> Pixel & Dot Farm — sibling protector loop <span className="text-[#d8ae55]">+AC</span><br/>
                      <span className="mt-2 block text-[#d8ae55] font-bold">10 AC = $1 • terrain, sky, structures, decorations, textures, Mood Patches</span>
                    </div>
                    <div className="mt-3 pt-3 border-t border-white/10 label text-white/30 text-[9px] leading-[1.4]">Asset ladder: blur placeholder → fade-in → focus • 800×1120 centered • gold border</div>
                  </div>
                </div>
              </div>
            </div>

            {/* Environment plate + game cards */}
            <div className="mt-10 grid grid-cols-1 lg:grid-cols-[1.15fr_0.85fr] gap-6 md:gap-8 items-start">
              {/* Left: full-bleed environment detail card with arrival feel */}
              <div className="relative rounded-[24px] p-[1px] overflow-hidden" style={{ animation: "blurResolve 1.8s ease-out both" }}>
                <div className="absolute inset-0 rounded-[24px] bg-gradient-to-br from-[#00eaff]/30 via-[#d8ae55]/20 to-[#ff00c8]/20 blur-[0.5px]" />
                <div className="relative rounded-[23px] overflow-hidden bg-[#050508]/80 backdrop-blur-[2px] border border-white/10">
                  {/* simulated world preview */}
                  <div className="relative aspect-[16/10] md:aspect-[16/11] bg-[#000] overflow-hidden">
                    {/* inner luminous world */}
                    <div className="absolute inset-0 bg-[radial-gradient(90%_70%_at_30%_20%,#1e2a44_0%,#12182a_30%,#0a0a10_65%,#000_90%)]" />
                    <div className="absolute inset-x-0 bottom-0 top-[48%] bg-gradient-to-t from-[#1a150e]/90 via-[#12110d]/50 to-transparent" />
                    {/* moon large */}
                    <div className="absolute right-[12%] top-[14%] h-[68px] w-[68px] rounded-full bg-[#e9e6d7] shadow-[0_0_28px_rgba(232,230,215,0.7),inset_-8px_-6px_18px_rgba(0,0,0,0.3)]">
                      <div className="absolute left-[18%] top-[22%] h-3 w-3 rounded-full bg-black/20" />
                      <div className="absolute right-[28%] bottom-[24%] h-4 w-4 rounded-full bg-black/15" />
                    </div>
                    {/* farmhouse detail */}
                    <div className="absolute left-[12%] bottom-[18%] w-[44%]">
                      <div className="flex gap-[6%] items-end">
                        <div className="flex-1">
                          <div className="h-[64px] bg-[#1b1610] border border-[#d8ae55]/30 rounded-t-[6px] relative">
                            <div className="absolute top-2 left-2 right-2 flex justify-between">
                              <div className="h-5 w-5 bg-[#ffeaa1] shadow-[0_0_12px_#ffec9a] rounded-[1px]" />
                              <div className="h-5 w-5 bg-[#ffeaa1] shadow-[0_0_12px_#ffec9a] rounded-[1px]" />
                            </div>
                            <div className="absolute bottom-2 left-1/2 -translate-x-1/2 h-6 w-3 bg-[#0a0806] border border-[#d8ae55]/20" />
                          </div>
                          <div className="h-2 bg-[#0e0c0a] border-x border-[#d8ae55]/20" />
                        </div>
                        <div className="w-[30%] h-[28px] bg-[#141423]/60 border border-white/10 rounded-[4px] grid place-items-center">
                          <span className="label text-[6px] text-white/30">WELL</span>
                        </div>
                      </div>
                      {/* berry rows */}
                      <div className="mt-3 grid grid-cols-8 gap-1">
                        {Array.from({ length: 16 }).map((_, i) => <div key={i} className="h-1 w-1 rounded-full bg-[#d8ae55] shadow-[0_0_6px_#d8ae55] opacity-70" />)}
                      </div>
                    </div>
                    {/* player + mount silhouette */}
                    <div className="absolute left-[52%] bottom-[22%] flex items-end gap-1">
                      <div className="h-3 w-2 bg-white/80 rounded-t-[2px]" />
                      <div className="h-4 w-7 bg-[#00eaff]/70 rounded-[4px] border border-[#00eaff]/50" />
                    </div>
                    {/* coins */}
                    <div className="absolute left-[28%] bottom-[44%] flex gap-2">
                      <div className="h-2 w-2 rounded-full bg-[#d8ae55] shadow-[0_0_8px_#d8ae55] animate-pulse" />
                      <div className="h-2 w-2 rounded-full bg-[#d8ae55]/60" />
                      <div className="h-2 w-2 rounded-full bg-[#00eaff] shadow-[0_0_8px_#00eaff]" />
                    </div>
                    <div className="absolute bottom-0 inset-x-0 h-[2px] bg-[#00eaff]/40 shadow-[0_0_12px_#00eaff]" />
                    <div className="absolute top-3 left-3 label px-2 py-1 rounded-full bg-black/60 border border-white/10 text-white/60">ARRIVAL • BLUR → FOCUS • 5% BREATHE</div>
                    <div className="absolute top-3 right-3 label px-2 py-1 rounded-full bg-[#00eaff]/15 text-[#00eaff] border border-[#00eaff]/20">ACTIVE • LIVE</div>
                  </div>
                  <div className="p-5 md:p-6 grid grid-cols-1 md:grid-cols-2 gap-5">
                    <div>
                      <div className="label text-[#d8ae55] mb-2">ZONES • 5 • WASD</div>
                      <div className="space-y-2">
                        {FARM_ZONES.map(z => (
                          <div key={z.id} className="flex gap-2.5 items-start rounded-[10px] bg-white/[0.03] border border-white/5 px-3 py-2">
                            <div className="h-1.5 w-1.5 rounded-full mt-1.5 shrink-0" style={{ background: z.accent, boxShadow: `0 0 8px ${z.accent}` }} />
                            <div>
                              <div className="flex items-center gap-2">
                                <span className="mono text-[11px] font-bold">{z.name}</span>
                                <span className="label text-[8px] px-1.5 py-0.5 rounded-full bg-white/5 border border-white/10 text-white/40">{z.role}</span>
                              </div>
                              <div className="text-[11px] leading-[1.4] text-white/50 mt-0.5">{z.desc}</div>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                    <div>
                      <div className="label text-[#00eaff] mb-2">MOUNTS ROSTER • RECONCILED • 2X AT SALOON</div>
                      <div className="grid grid-cols-1 gap-2">
                        {FARM_MOUNTS.map(m => (
                          <div key={m.name} className="flex items-center justify-between rounded-[10px] bg-[#0A0A10] border border-white/5 px-3 py-2">
                            <div className="flex items-center gap-2.5 min-w-0">
                              <div className="h-2 w-2 rounded-full shrink-0" style={{ background: m.color, boxShadow: `0 0 8px ${m.color}` }} />
                              <span className="mono text-[11px] font-bold truncate">{m.name}</span>
                            </div>
                            <div className="text-right shrink-0 ml-3">
                              <div className="label text-[8px] text-white/60">{m.trait}</div>
                              <div className="label text-[7px] text-white/30 hidden md:block">{m.detail}</div>
                            </div>
                          </div>
                        ))}
                      </div>
                      <div className="mt-3 label text-[9px] leading-[1.4] text-white/30">Rainbow Pop / Paint Random Pop skins • Sassy Saloon HQ equip • Skins switchable</div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Right: game cards + virtues */}
              <div className="flex flex-col gap-4">
                <div className="grid grid-cols-1 gap-3">
                  {FARM_GAMES.map(g => (
                    <div key={g.k} className="group rounded-[18px] glass p-4 border border-white/10 hover:border-[#00eaff]/20 transition">
                      <div className="flex items-start justify-between gap-3">
                        <div className="flex items-center gap-2">
                          <span className="mono text-[10px] tracking-[0.2em] text-white/30">{g.k}</span>
                          <span className="h-5 w-5 rounded-full bg-[#0A0A10] border border-white/10 grid place-items-center mono text-[10px] text-white/60">{g.title[0]}</span>
                        </div>
                        <span className="label text-[8px] px-2 py-1 rounded-full border" style={{ background: `${g.accent}14`, color: g.accent, borderColor: `${g.accent}30` }}>{g.tag}</span>
                      </div>
                      <h3 className="mt-3 mono text-[14px] font-bold leading-tight">{g.title}</h3>
                      <p className="mt-2 text-[12px] leading-[1.5] text-white/60">{g.desc}</p>
                      <div className="mt-3 h-px bg-white/5" />
                      <div className="mt-2 flex items-center gap-2">
                        <div className="h-1 w-1 rounded-full bg-[#00eaff] animate-pulse" />
                        <span className="label text-white/40 text-[8px]">PLAYABLE CORE • PRO EDITION • BLACK BRAND • NO TEXT BURNED INTO ART</span>
                      </div>
                    </div>
                  ))}
                </div>

                <div className="rounded-[18px] glass-gold p-4 border border-[#d8ae55]/20">
                  <div className="flex items-center justify-between mb-3">
                    <span className="label text-[#d8ae55]">VIRTUE COLLECTIBLES • MISSION CARRYING</span>
                    <span className="label text-[8px] px-2 py-0.5 rounded-full bg-[#d8ae55]/15 text-[#d8ae55] border border-[#d8ae55]/30 font-bold">VOICE LINES • EARNS AC</span>
                  </div>
                  <div className="space-y-2.5">
                    {FARM_VIRTUES.map(v => (
                      <div key={v.name} className="rounded-[12px] bg-black/40 border border-white/5 px-3 py-2.5 flex gap-3">
                        <div className="h-2 w-2 rounded-full mt-1.5 shrink-0" style={{ background: v.color, boxShadow: `0 0 8px ${v.color}` }} />
                        <div className="min-w-0">
                          <div className="mono text-[11px] font-bold">{v.name}</div>
                          <div className="mt-1 text-[11px] leading-[1.4] text-white/55 italic">“{v.line}”</div>
                        </div>
                      </div>
                    ))}
                  </div>
                  <div className="mt-3 pt-3 border-t border-[#d8ae55]/10 flex flex-wrap gap-2">
                    <span className="label text-[8px] px-2 py-1 rounded-full bg-white/5 border border-white/10 text-white/40">Moderators patrol (no bouncers) • pure AO</span>
                    <span className="label text-[8px] px-2 py-1 rounded-full bg-[#d8ae55]/15 border border-[#d8ae55]/30 text-[#d8ae55] font-bold">BLING → ANOM COIN • EVERYTHING EARNS AC</span>
                    <span className="label text-[8px] px-2 py-1 rounded-full bg-white/5 border border-white/10 text-white/40">FUBAR=AO</span>
                    <span className="label text-[8px] px-2 py-1 rounded-full bg-[#d8ae55]/10 border border-[#d8ae55]/20 text-[#d8ae55]">Sentinel Code on planet</span>
                    <span className="label text-[8px] px-2 py-1 rounded-full bg-[#00eaff]/10 border border-[#00eaff]/20 text-[#00eaff]">10 AC = $1 BUILD</span>
                  </div>
                </div>

                <div className="glass rounded-[14px] p-4 border border-white/10">
                  <div className="flex items-start gap-3">
                    <div className="h-8 w-8 rounded-full bg-[#d8ae55]/15 border border-[#d8ae55]/20 grid place-items-center text-[#d8ae55] mono text-[12px] shrink-0">◐</div>
                    <div>
                      <div className="mono text-[11px] tracking-[0.18em] font-bold">COLOR CORNER LINKAGE • <span className="text-[#d8ae55]">ANOM COIN</span></div>
                      <p className="mt-1 text-[12px] leading-[1.5] text-white/60">Kids color their own travel animals in Anom's Corner — those animals carry you to Moonberry. Physical → upload → Anom Coin → ride what you colored. Everything they do earns Anom Coin. Archive remembers stroke. Tater & Clifford approved. 10 AC = $1 utility.</p>
                      <button onClick={() => document.getElementById('color')?.scrollIntoView({behavior:'smooth'})} className="mt-2 label text-[#00eaff] hover:text-white transition">GO TO COLOR CORNER →</button>
                    </div>
                  </div>
                </div>

                <div className="rounded-[14px] bg-[#ff00c8]/10 border border-[#ff00c8]/20 p-3 flex items-center justify-between gap-3">
                  <div className="text-[11px] leading-[1.4] text-white/70"><span className="mono text-[10px] tracking-[0.18em] font-bold text-[#ff00c8]">REMINDER • IN BUILD (MAGENTA):</span> Mood Memes Lounges + Public Profile still to build from Manus DB mix-up. Not lost — tracked here. Economy now Anom Coin everywhere.</div>
                  <div className="h-2 w-2 rounded-full bg-[#ff00c8] shadow-[0_0_10px_#ff00c8] animate-pulse shrink-0" />
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* COLOR CORNER */}
      <section id="color" className="relative z-10 w-full px-6 md:px-10 py-16 md:py-24 bg-[#04040a]/90 border-t border-white/5">
        <div className="mx-auto max-w-[1280px]">
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-10">
            <div>
              <div className="flex items-center gap-3 mb-3">
                <span className="label text-[#00eaff]">01 — THE BEINGS</span>
                <span className="label px-2.5 py-1 rounded-full bg-[#d8ae55]/20 border border-[#d8ae55]/30 text-[#d8ae55] font-bold">EVERYTHING THEY DO EARNS ANOM COIN</span>
              </div>
              <h2 className="mono text-[28px] md:text-[40px] font-bold leading-[0.95]">COLOR CORNER</h2>
              <p className="mt-3 max-w-[560px] text-[14px] leading-[1.6] text-white/60">
                The travel animals. Ridable mounts that carry members between worlds, wearing emotes.
                Kid colors animal → earns <span className="text-[#d8ae55] font-bold">Anom Coin</span> — everything you do earns Anom Coin → rides what they colored.
                Archive remembers every stroke. 10 AC = $1 utility token.
              </p>
            </div>
            <div className="glass rounded-[16px] px-4 py-3 flex items-center gap-3 max-w-[360px]">
              <div className="h-8 w-8 rounded-full bg-[#d8ae55]/20 grid place-items-center text-[#d8ae55] mono text-xs">AC</div>
              <div className="text-[12px] leading-tight text-white/70"><span className="text-[#d8ae55] mono text-[11px] tracking-[0.18em] font-bold">ANOM COIN • 10 AC = $1</span><br/>Care, not speed. Calm earns more. Building currency.</div>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-5 md:gap-6">
            {COLOR_BEINGS.map((b) => (
              <div
                key={b.title}
                className="group relative rounded-[24px] p-[1px] transition-transform duration-500 hover:-translate-y-1"
                style={{ animation: `breathe ${3.4 + Math.random()}s ease-in-out infinite` }}
              >
                <div className="absolute inset-0 rounded-[24px] opacity-60 group-hover:opacity-90 transition" style={{ background: `linear-gradient(135deg, ${b.accent}55, transparent)` }} />
                <div className="relative rounded-[23px] glass overflow-hidden min-h-[420px] flex flex-col">
                  {/* art plate 800x1120 ratio */}
                  <div className="relative aspect-[800/1120] md:aspect-[800/920] m-3 rounded-[16px] overflow-hidden bg-[#0A0A10] border border-white/10">
                    <div className="absolute inset-0 bg-[radial-gradient(120%_90%_at_50%_10%,rgba(255,255,255,0.08),transparent_60%)]" />
                    <div className="absolute inset-0 grid place-items-center">
                      <div className="relative">
                        <div className="text-[84px] leading-none select-none opacity-90" style={{ color: b.accent, filter: `drop-shadow(0 0 18px ${b.accent})` }}>{b.emote}</div>
                        <div className="absolute -bottom-2 left-1/2 -translate-x-1/2 h-[2px] w-[52px] rounded-full" style={{ background: b.accent, boxShadow: `0 0 12px ${b.accent}` }} />
                      </div>
                    </div>
                    <div className="absolute bottom-0 inset-x-0 h-[38%] bg-gradient-to-t from-black/80 to-transparent" />
                    <div className="absolute bottom-3 left-3 right-3 flex justify-between items-center">
                      <span className="label px-2 py-1 rounded-full bg-black/60 border border-white/10 text-white/60">{b.label}</span>
                      <span className="label text-[9px] px-2 py-1 rounded-full" style={{ background: `${b.accent}18`, color: b.accent, border: `1px solid ${b.accent}40` }}>800×1120 • CENTERED</span>
                    </div>
                  </div>
                  <div className="p-5 pt-2 flex flex-col flex-1">
                    <h3 className="mono text-[16px] font-bold tracking-[0.02em]">{b.title}</h3>
                    <p className="mt-2 text-[13px] leading-[1.5] text-white/60 flex-1">{b.copy}</p>
                    <div className="mt-4 flex items-center gap-2">
                      <div className="h-px flex-1 bg-white/10" />
                      <span className="label text-white/30">ANOM ORIGINAL</span>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* HOUSE THREE */}
      <section id="houses" className="relative z-10 w-full px-6 md:px-10 py-16 md:py-24 bg-black border-t border-white/[0.06]">
        <div className="mx-auto max-w-[1280px]">
          <div className="flex flex-wrap items-baseline gap-4 mb-10">
            <h2 className="mono text-[28px] md:text-[40px] font-bold">HOUSE THREE — GAME BUILDS</h2>
            <span className="label text-white/40">ACTUAL SHIPPED WORLDS • 4 HOUSES + MOONBERRY • NEVER SYNCED</span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-5">
            {HOUSES.map((h) => (
              <button
                key={h.id}
                onClick={() => setSelected(h)}
                className="group text-left rounded-[24px] p-[1px] focus:outline-none focus-visible:ring-2 focus-visible:ring-[#00eaff]/50"
                style={{ animation: `breathe ${h.breathe} ease-in-out infinite` }}
              >
                <div className="rounded-[23px] glass-gold h-full overflow-hidden flex flex-col min-h-[520px]">
                  <div className="relative aspect-[800/1120] m-3 rounded-[16px] overflow-hidden bg-[#0A0A10] border border-[#d8ae55]/20">
                    {/* art centered generous margin */}
                    <div className="absolute inset-[10%] rounded-[12px] border border-white/[0.06] bg-[radial-gradient(100%_100%_at_50%_0%,rgba(216,174,85,0.18),transparent_70%)]" />
                    <div className="absolute inset-0 grid place-items-center">
                      <div className="text-center px-6">
                        <div className="mono text-[11px] tracking-[0.24em] text-[#d8ae55]/70">{h.tag}</div>
                        <div className="mt-3 mono text-[18px] leading-[1.05] font-bold">{h.title}</div>
                        <div className="mt-3 h-[1px] w-12 mx-auto bg-[#00eaff]/60 shadow-[0_0_8px_#00eaff]" />
                        <div className="mt-3 text-[12px] leading-[1.5] text-white/50">{h.subtitle}</div>
                        <div className="mt-6 inline-flex items-center gap-2 rounded-full px-3 py-1 bg-white/[0.06] border border-white/10">
                          <div className="h-1.5 w-1.5 rounded-full bg-[#00eaff] animate-pulse" />
                          <span className="label text-white/70">{h.breathe} BREATHE</span>
                        </div>
                      </div>
                    </div>
                    {/* gold border accent */}
                    <div className="absolute inset-0 rounded-[16px] pointer-events-none" style={{ boxShadow: `inset 0 0 0 1px ${COLORS.gold}30` }} />
                  </div>
                  <div className="px-5 pb-5 pt-1 flex flex-col flex-1">
                    <p className="text-[13px] leading-[1.55] text-white/65">{h.desc}</p>
                    <div className="mt-auto pt-4 flex items-center justify-between">
                      <span className="label text-[#00eaff]">OPEN WORLD →</span>
                      <span className="label text-white/30">{h.id.toUpperCase()}</span>
                    </div>
                  </div>
                </div>
              </button>
            ))}
          </div>
        </div>
      </section>

      {/* MOONBERRY — GAMES WE MADE */}
      <section id="moonberry" className="relative z-10 w-full px-6 md:px-10 py-16 md:py-24 bg-[#04040a] border-t border-[#d8ae55]/15 overflow-hidden">
        <div className="absolute inset-0 pointer-events-none">
          <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 h-[120%] w-[80%] rounded-full bg-[radial-gradient(60%_60%_at_50%_30%,rgba(216,174,85,0.14),transparent_70%)] blur-[1px]" />
          <div className="absolute inset-0 opacity-30" style={{ backgroundImage: `radial-gradient(rgba(216,174,85,0.22) 1px, transparent 1px)`, backgroundSize: "32px 32px" }} />
        </div>
        <div className="relative mx-auto max-w-[1280px]">
          <div className="flex flex-col lg:flex-row gap-10 items-start">
            <div className="lg:w-[38%] shrink-0">
              <div className="flex items-center gap-3 mb-4">
                <div className="h-2 w-2 rounded-full bg-[#d8ae55] shadow-[0_0_12px_#d8ae55] animate-pulse" />
                <span className="label text-[#d8ae55]">MOON WORLD • 4.3S BREATHE • NEVER SYNCED</span>
                <span className="label px-2 py-0.5 rounded-full bg-[#00eaff]/10 text-[#00eaff] border border-[#00eaff]/20">GAMES LIVE</span>
              </div>
              <h2 className="mono text-[36px] md:text-[48px] font-bold leading-[0.9] tracking-[-0.02em]">MOON<span className="text-[#d8ae55]">BERRY</span></h2>
              <p className="mono text-[11px] tracking-[0.22em] text-white/40 mt-2 uppercase">Where the games we made orbit • Low-gravity arcade</p>
              <button onClick={() => setSelected(MOONBERRY as any)} className="mt-6 w-full text-left rounded-[20px] p-[1px] focus:outline-none focus-visible:ring-2 focus-visible:ring-[#d8ae55]/40" style={{ animation: `breathe ${MOONBERRY.breathe} ease-in-out infinite` }}>
                <div className="rounded-[19px] glass-gold p-5 group-hover:bg-white/[0.02]">
                  <div className="aspect-[800/1120] relative rounded-[14px] overflow-hidden bg-black border border-[#d8ae55]/20">
                    <div className="absolute inset-0 bg-[radial-gradient(90%_70%_at_50%_20%,#2a2212,#0a0a10_75%)]" />
                    {/* crater field */}
                    <div className="absolute inset-0">
                      <div className="absolute left-[18%] top-[22%] h-[44px] w-[44px] rounded-full bg-white/[0.06] border border-white/10" />
                      <div className="absolute left-[22%] top-[26%] h-[12px] w-[12px] rounded-full bg-black/60" />
                      <div className="absolute right-[28%] top-[34%] h-[28px] w-[28px] rounded-full bg-white/[0.05] border border-white/5" />
                      <div className="absolute right-[34%] bottom-[28%] h-[54px] w-[54px] rounded-full bg-white/[0.04] border border-white/5" />
                      <div className="absolute left-[30%] bottom-[18%] h-[20px] w-[20px] rounded-full bg-white/[0.06]" />
                    </div>
                    {/* tiny arcade silhouette */}
                    <div className="absolute bottom-[14%] left-1/2 -translate-x-1/2 flex gap-2">
                      <div className="h-[28px] w-[18px] rounded-t-[4px] bg-[#d8ae55]/30 border border-[#d8ae55]/40" />
                      <div className="h-[32px] w-[20px] rounded-t-[4px] bg-[#00eaff]/30 border border-[#00eaff]/40" />
                      <div className="h-[26px] w-[16px] rounded-t-[4px] bg-[#ff00c8]/30 border border-[#ff00c8]/40" />
                    </div>
                    <div className="absolute top-6 left-6 right-6 flex justify-between">
                      <span className="label px-2 py-1 rounded-full bg-black/50 border border-white/10 text-white/50">800×1120 • CENTERED</span>
                      <span className="label px-2 py-1 rounded-full bg-[#d8ae55]/15 text-[#d8ae55]">MOON POST • CLIFFORD</span>
                    </div>
                    <div className="absolute bottom-5 left-1/2 -translate-x-1/2 text-center">
                      <div className="mono text-[10px] tracking-[0.3em] text-[#d8ae55]/80">BEAM IN • RIDE CALM</div>
                    </div>
                  </div>
                  <p className="mt-4 text-[13px] leading-[1.6] text-white/65">{MOONBERRY.long}</p>
                  <div className="mt-4 flex gap-2">
                    <span className="label px-2.5 py-1 rounded-full glass text-white/50">LOW-G</span>
                    <span className="label px-2.5 py-1 rounded-full glass-gold text-[#d8ae55] font-bold">ANOM COIN EARNABLE • EVERYTHING EARNS</span>
                    <span className="label px-2.5 py-1 rounded-full bg-[#00eaff]/10 text-[#00eaff] border border-[#00eaff]/20">{MOONBERRY.breathe}</span>
                    <span className="label px-2.5 py-1 rounded-full bg-[#d8ae55]/15 text-[#d8ae55] border border-[#d8ae55]/25">10 AC = $1</span>
                  </div>
                </div>
              </button>
            </div>

            <div className="flex-1 min-w-0">
              <div className="flex items-baseline justify-between gap-4 mb-5">
                <h3 className="mono text-[14px] tracking-[0.22em] text-white/60">GAMES WE MADE — PLAYABLE BUILDS</h3>
                <span className="label text-[#d8ae55] font-bold">EVERYTHING EARNS ANOM COIN • 10 AC = $1</span>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {MOONBERRY.games.map((g, i) => (
                  <div key={g.name} className="group rounded-[16px] glass p-4 flex flex-col gap-3 hover:bg-white/[0.06] transition border border-white/10 hover:border-[#d8ae55]/20">
                    <div className="flex items-start justify-between gap-3">
                      <div className="h-8 w-8 rounded-full bg-[#0A0A10] border border-white/10 grid place-items-center mono text-[11px] text-white/60">{i+1}</div>
                      <span className={`label px-2 py-1 rounded-full border ${g.status === "PLAYABLE" ? "bg-[#00eaff]/10 text-[#00eaff] border-[#00eaff]/20" : "bg-[#ff00c8]/10 text-[#ff00c8] border-[#ff00c8]/20"}`}>{g.status}</span>
                    </div>
                    <div>
                      <div className="mono text-[13px] font-bold leading-tight">{g.name}</div>
                      <div className="mt-1 text-[11px] text-white/50 leading-[1.4]"><span className="text-[#d8ae55] font-bold">{g.glow}</span> — Earns Anom Coin • 10 AC = $1 building utility</div>
                    </div>
                    <div className="mt-auto flex items-center gap-2">
                      <div className="h-px flex-1 bg-white/10" />
                      <button onClick={() => { const el = document.getElementById('color'); el?.scrollIntoView({behavior:'smooth'}); }} className="label text-[#d8ae55] hover:text-white transition">RIDE TO PLAY →</button>
                    </div>
                  </div>
                ))}
              </div>
              <div className="mt-6 glass rounded-[14px] p-4 flex flex-col md:flex-row gap-4 items-start md:items-center justify-between">
                <div className="text-[12px] leading-[1.5] text-white/60 max-w-[520px]">
                  <span className="text-[#d8ae55] mono text-[11px] tracking-[0.18em] font-bold">HOW IT WORKS • EVERYTHING EARNS ANOM COIN:</span> You color a mount in Color Corner → earn Anom Coin for calm rides → beam to Moonberry → playtest → Tater &amp; Clifford log your Anom Coin. 10 AC = $1 utility token for building, terrain, sky, structures, decorations, textures, Mood Patches. Building currency. Sentinel Code applies on moon too.
                </div>
                <div className="flex gap-2 shrink-0">
                  <div className="h-8 w-8 rounded-full bg-[#d8ae55]/20 grid place-items-center text-[#d8ae55] mono text-[10px]">T</div>
                  <div className="h-8 w-8 rounded-full bg-[#00eaff]/20 grid place-items-center text-[#00eaff] mono text-[10px]">C</div>
                  <div className="h-8 w-8 rounded-full bg-white/10 grid place-items-center text-white/60 mono text-[10px]">M</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* REMAINING BUILDS BANNER */}
      <section id="build" className="relative z-10 w-full px-6 md:px-10 py-14 bg-[#0A0A10] border-y border-white/5">
        <div className="mx-auto max-w-[1280px]">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6">
            <div className="flex items-center gap-3">
              <div className="h-2 w-2 rounded-full bg-[#ff00c8] shadow-[0_0_12px_#ff00c8] animate-pulse" />
              <h3 className="mono text-[14px] md:text-[16px] font-bold tracking-[0.18em]">REMAINING BUILDS — FROM MANUS DB MIX-UP</h3>
              <span className="label px-2.5 py-1 rounded-full bg-[#ff00c8]/15 text-[#ff00c8] border border-[#ff00c8]/30">IN BUILD</span>
            </div>
            <span className="label text-white/40">SO WE DON&apos;T GET LOST AGAIN • STATUS: MAGENTA = IN BUILD</span>
          </div>

          <div className="glass rounded-[20px] p-4 md:p-6">
            <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-7 gap-3">
              {REMAINING.map((item) => (
                <div key={item} className="group rounded-[14px] border border-white/10 bg-white/[0.03] px-4 py-3 flex items-center justify-between gap-2 hover:bg-white/[0.05] transition">
                  <span className="text-[12px] leading-tight text-white/80">{item}</span>
                  <span className="label shrink-0 px-2 py-1 rounded-full bg-[#ff00c8]/15 text-[#ff00c8] border border-[#ff00c8]/25">IN BUILD</span>
                </div>
              ))}
            </div>
            <div className="mt-4 flex flex-wrap gap-2">
              <span className="label text-white/30">NOTE: Mood Memes Lounges to build yet from Manus DB mix-up</span>
              <span className="label text-[#d8ae55]/60">• Public Profiles + Identity Shop linked</span>
              <span className="label text-[#00eaff]/60">• Feed soft-delete protects kids</span>
            </div>
          </div>
        </div>
      </section>

      {/* SAFETY */}
      <section className="relative z-10 w-full px-6 md:px-10 py-16 md:py-20 bg-[#04040a]">
        <div className="mx-auto max-w-[1280px] grid md:grid-cols-[1.1fr_0.9fr] gap-8 md:gap-12 items-start">
          <div>
            <div className="label text-[#d8ae55] mb-3">04 — SAFETY</div>
            <h3 className="mono text-[26px] md:text-[32px] font-bold leading-[0.95]">Moderators who PATROL<br/><span className="text-white/40">No bouncers. Pure AO.</span></h3>
            <div className="mt-6 grid grid-cols-2 gap-3 max-w-[520px]">
              <div className="glass rounded-[14px] p-4">
                <div className="label text-[#00eaff] mb-1">PATROL</div>
                <div className="text-[12px] text-white/60 leading-[1.5]">Moderators walk, not gatekeep. Presence over power.</div>
              </div>
              <div className="glass rounded-[14px] p-4">
                <div className="label text-[#d8ae55] mb-1">STEWARD</div>
                <div className="text-[12px] text-white/60 leading-[1.5]">Ambassadors steward rooms. They hold vibe, not ban-hammer.</div>
              </div>
            </div>
            <div className="mt-6 glass rounded-[16px] p-5 max-w-[560px]">
              <div className="label text-white/50 mb-3">SENTINEL CODE</div>
              <div className="grid grid-cols-2 gap-3 text-[12px]">
                <div className="flex gap-2"><span className="text-[#00eaff]">■</span><span className="text-white/70">SFW — always</span></div>
                <div className="flex gap-2"><span className="text-[#ff00c8]">■</span><span className="text-white/70">Identity Guard — no dox, no leaks</span></div>
                <div className="flex gap-2"><span className="text-[#d8ae55]">■</span><span className="text-white/70">No Toxicity — mood-first respect</span></div>
                <div className="flex gap-2"><span className="text-white/40">■</span><span className="text-white/70">Mood-first respect — pause &gt; punish</span></div>
              </div>
              <div className="mt-4 pt-4 border-t border-white/5 flex flex-wrap gap-2">
                <span className="label px-2.5 py-1 rounded-full bg-[#d8ae55]/15 border border-[#d8ae55]/25 text-[#d8ae55] font-bold">EVERYTHING THEY DO EARNS ANOM COIN • 10 AC = $1 BUILD</span>
                <span className="label px-2.5 py-1 rounded-full bg-white/5 border border-white/10 text-white/50">bling = anom coin • old chasing now earning</span>
                <span className="label px-2.5 py-1 rounded-full bg-white/5 border border-white/10 text-white/50">fubar = AO • translation applied</span>
                <span className="label px-2.5 py-1 rounded-full bg-[#ff00c8]/10 border border-[#ff00c8]/20 text-[#ff00c8]">SENTINEL ACTIVE • PATROL NO BOUNCERS</span>
              </div>
            </div>
          </div>
          <div className="glass rounded-[20px] p-5 md:p-6">
            <div className="label text-white/40 mb-4">TRANSLATION LEDGER</div>
            <div className="space-y-3">
              {[
                { from: "Bling", to: "Anom Coin", note: "Old chasing = now Anom Coin earning. Everything earns." },
                { from: "Glow", to: "Anom Coin", note: "Glow merged → Anom Coin • 10 AC = $1 building utility" },
                { from: "Bouncers", to: "Patrol", note: "Term removed — pure AO" },
                { from: "Glitch", to: "Anomoly", note: "Always with O — never glitch" },
              ].map((r) => (
                <div key={r.from} className="flex items-center justify-between gap-3 rounded-[12px] bg-black/40 border border-white/5 px-4 py-3">
                  <div className="flex items-center gap-3">
                    <span className="mono text-[11px] text-white/30 line-through">{r.from}</span>
                    <span className="text-white/20">→</span>
                    <span className="mono text-[12px] font-bold text-[#00eaff]">{r.to}</span>
                  </div>
                  <span className="label text-white/40 text-[9px] text-right max-w-[160px]">{r.note}</span>
                </div>
              ))}
            </div>
            <div className="mt-4 pt-4 border-t border-[#d8ae55]/15">
              <div className="label text-[#d8ae55] font-bold mb-1">ECONOMY CANON • UPDATED</div>
              <div className="mono text-[10px] leading-[1.6] text-white/60">
                EVERYTHING THEY DO EARNS ANOM COIN — color, harvest, patrol, hold space, link check.<br/>
                10 AC = $1 USD utility token for building, terrain, sky, structures, decorations, textures, Mood Patches.<br/>
                Building currency. Free homeworld (anomartsy.xyz) but earning is everywhere.
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* STORE LINK */}
      <section className="relative z-10 w-full px-6 md:px-10 py-16 md:py-20 bg-black border-t border-white/5">
        <div className="mx-auto max-w-[1280px]">
          <div className="relative overflow-hidden rounded-[24px] md:rounded-[32px] border border-[#d8ae55]/30 p-[1px]">
            <div className="absolute inset-0 bg-[radial-gradient(90%_120%_at_20%_10%,rgba(216,174,85,0.18),transparent_60%),radial-gradient(80%_100%_at_80%_20%,rgba(0,234,255,0.12),transparent_60%)]" />
            <div className="relative rounded-[23px] md:rounded-[31px] bg-[#0A0A10] px-6 md:px-10 py-8 md:py-12 flex flex-col md:flex-row md:items-center justify-between gap-8">
              <div className="max-w-[620px]">
                <div className="flex items-center gap-3 mb-3">
                  <span className="label text-[#d8ae55]">THE ANOMOLY ARCHIVE</span>
                  <span className="label px-2 py-1 rounded-full bg-[#d8ae55]/15 text-[#d8ae55] border border-[#d8ae55]/25">112+ ASSETS • DIGITAL-ONLY</span>
                  <span className="label px-2 py-1 rounded-full bg-[#d8ae55]/20 text-[#d8ae55] border border-[#d8ae55]/30 font-bold">10 AC = $1 BUILD</span>
                </div>
                <h3 className="mono text-[24px] md:text-[36px] font-bold leading-[0.95]">XYZ is free home.<br/><span className="text-[#d8ae55]">LOL is money.</span></h3>
                <p className="mt-3 text-[13px] leading-[1.6] text-white/60">
                  anomartsy.xyz = homeworld (this portal). anomarsty.lol = store — note transposition <span className="text-white">rtsy vs rsty</span>.
                  Free homeworld but everything earns Anom Coin — color, harvest, patrol, hold space, link check. 10 AC = $1 utility for terrain, sky, structures, decorations, textures, Mood Patches.
                </p>
                <div className="mt-4 flex flex-wrap gap-2">
                  <span className="label text-white/30">DOMAINS</span>
                  <span className="label px-2.5 py-1 rounded-full glass text-white/60">anomartsy.xyz = homeworld</span>
                  <span className="label px-2.5 py-1 rounded-full glass-gold text-[#d8ae55]">anomarsty.lol = store</span>
                  <span className="label px-2.5 py-1 rounded-full bg-[#d8ae55]/15 border border-[#d8ae55]/20 text-[#d8ae55] font-bold">EVERYTHING EARNS ANOM COIN</span>
                </div>
              </div>
              <div className="shrink-0">
                <a
                  href="https://anomarsty.lol"
                  target="_blank"
                  rel="noopener"
                  className="group relative inline-flex items-center gap-3 rounded-full bg-white text-black px-8 py-4 mono text-[13px] font-bold tracking-[0.18em] hover:bg-[#d8ae55] transition"
                >
                  <span>ENTER ARCHIVE — ANOMARSTY.LOL</span>
                  <span className="h-6 w-6 rounded-full bg-black text-white grid place-items-center group-hover:rotate-45 transition-transform">↗</span>
                </a>
                <div className="mt-3 label text-center text-white/30">MISSPELLED RSTY INTENTIONAL</div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* FOOTER */}
      <footer className="relative z-10 w-full border-t border-white/5 bg-[#04040a] px-6 md:px-10 py-10">
        <div className="mx-auto max-w-[1280px] flex flex-col md:flex-row justify-between gap-6">
          <div>
            <div className="flex items-center gap-2">
              <div className="h-6 w-6 rounded-full bg-white/10 grid place-items-center mono text-[9px]">AO</div>
              <span className="mono text-[12px] font-bold tracking-[0.12em]">ANOM ORIGINALS</span>
              <span className="label text-white/30">Woodbridge VA</span>
            </div>
            <div className="mt-3 text-[12px] leading-[1.6] text-white/40 max-w-[420px]">
              Anom Originals, Woodbridge VA — anom@anomartsy.xyz<br/>
              anomartsy.xyz = homeworld · anomarsty.lol = store (rtsy vs rsty transposition noted).<br/>
              Never use word glitch. Always Anomoly with O. Black brand forward. Gold borders. Art centered.
            </div>
          </div>
          <div className="flex flex-col gap-2 text-right md:text-left">
            <span className="label text-white/20">CANON CHECK</span>
            <span className="label text-white/50">#000000 BG • #0A0A10 VOID • #00EAFF CYAN • #FF00C8 MAGENTA • #D8AE55 GOLD</span>
            <span className="label text-white/30">Space Mono display / Inter UI • Glass 135deg 0.12→0.04 blur 18px • Radii 16-24px</span>
            <span className="label text-[#00eaff]/60">180 stars • floatY 6s • moon 4s • houses 3.2 / 3.6 / 3.9 / 4.1 never synced</span>
          </div>
        </div>
      </footer>

      {/* MODAL */}
      {selected && (
        <div className="fixed inset-0 z-[70] flex items-center justify-center p-4">
          <button aria-label="Close" onClick={() => setSelected(null)} className="absolute inset-0 bg-black/70 backdrop-blur-[10px]" />
          <div className="relative w-full max-w-[520px] rounded-[24px] p-[1px] animate-[breathe_3.6s_ease-in-out_infinite]">
            <div className="rounded-[23px] glass overflow-hidden">
              <div className="relative p-6 md:p-7">
                <div className="flex items-start justify-between gap-4">
                  <div>
                    <div className="label text-[#d8ae55]">{selected.tag} • {selected.breathe} BREATHE</div>
                    <h3 className="mono text-[22px] font-bold leading-[1] mt-2">{selected.title}</h3>
                    <p className="mt-2 text-[12px] text-white/50">{selected.subtitle}</p>
                  </div>
                  <button onClick={() => setSelected(null)} className="h-8 w-8 rounded-full bg-white/10 grid place-items-center hover:bg-white/20 transition">✕</button>
                </div>

                <div className="mt-6 aspect-[800/560] rounded-[16px] overflow-hidden bg-[#0A0A10] border border-white/10 grid place-items-center p-6">
                  <div className="text-center max-w-[360px]">
                    <div className="mono text-[11px] tracking-[0.2em] text-white/30">WORLD PREVIEW • GENEROUS MARGIN • NO TEXT BURNED INTO ART</div>
                    <div className="mt-4 text-[13px] leading-[1.6] text-white/70">{selected.long}</div>
                    <div className="mt-5 inline-flex gap-2">
                      <span className="label px-3 py-1 rounded-full bg-[#00eaff]/10 text-[#00eaff] border border-[#00eaff]/20">SFV READY</span>
                      <span className="label px-3 py-1 rounded-full bg-[#d8ae55]/10 text-[#d8ae55] border border-[#d8ae55]/20">800×1120 GOLD BORDER</span>
                    </div>
                  </div>
                </div>

                <div className="mt-5 flex gap-2">
                  <button onClick={() => setSelected(null)} className="flex-1 rounded-full bg-white text-black mono text-[11px] tracking-[0.18em] py-3 font-bold hover:bg-[#00eaff] transition">CLOSE</button>
                  <a href="https://anomarsty.lol" target="_blank" rel="noopener" className="flex-1 rounded-full glass text-center mono text-[11px] tracking-[0.18em] py-3 text-white/70 hover:text-white transition">VIEW IN ARCHIVE →</a>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
